package com.backend.clinicaOdontologica.dto.modificacion;

public class TurnoModificacionEntradaDto {
}
