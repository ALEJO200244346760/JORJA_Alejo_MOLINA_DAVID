package com.backend.clinicaOdontologica.test;


import com.backend.clinicaOdontologica.dto.entrada.paciente.DomicilioEntradaDto;
import com.backend.clinicaOdontologica.dto.entrada.paciente.PacienteEntradaDto;
import com.backend.clinicaOdontologica.dto.salida.paciente.PacienteSalidaDto;
import com.backend.clinicaOdontologica.service.impl.PacienteService;
import org.junit.Test;
import org.junit.jupiter.api.Order;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
@RunWith(SpringRunner.class)
@SpringBootTest
public class PacienteServiceTest {

    @Autowired
    private PacienteService pacienteService;

    @Test
    @Order(1)
    public void deberiaAgregarUnPacienteDeNombreJulianYRetornarSuId(){
        PacienteEntradaDto pacienteEntradaDto = new PacienteEntradaDto("Alejo", "Jorja", 44346760, LocalDate.of(2023, 9,24), new DomicilioEntradaDto("Sosneado", 1892, "Córdoba Capital", "Córdoba"));

        PacienteSalidaDto pacienteSalidaDto = pacienteService.registrarPaciente(pacienteEntradaDto);

        assertNotNull(pacienteSalidaDto.getId());
        assertEquals("Alejo", pacienteSalidaDto.getNombre());
    }

//    @Test
//    @Order(2)
//    public void deberiaIntentarEliminarElPacienteConId1_SiNoLoEncontraraLanzariaUnaResourseNotFoundException(){
//
//        try {
//            pacienteService.eliminarPaciente(1L);
//        }catch(Exception exception){
//            exception.printStackTrace();
//        }
//
//        assertThrows(ResourceNotFoundException.class, ()-> pacienteService.eliminarPaciente(1L));
//    }

    @Test
    @Order(2)
    public void deberiaListarTodosLosPacientesRegistrados(){
        List<PacienteSalidaDto> pacientes = pacienteService.listarPacientes();
        PacienteEntradaDto pacienteEntradaDto = new PacienteEntradaDto("Juan", "Perez", 12345678, LocalDate.of(1990, 1, 1), new DomicilioEntradaDto("Calle Principal", 123, "Ciudad", "Provincia"));
        pacienteService.registrarPaciente(pacienteEntradaDto);
        // Verificar que la lista no sea nula y contenga al menos un paciente
        assertNotNull(pacientes);
        assertTrue(pacientes.size() > 0);
    }
}
