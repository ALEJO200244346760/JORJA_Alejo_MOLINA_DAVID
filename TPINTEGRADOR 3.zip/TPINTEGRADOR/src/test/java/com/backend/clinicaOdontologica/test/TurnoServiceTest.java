package com.backend.clinicaOdontologica.test;

import static org.junit.jupiter.api.Assertions.assertTrue;
import com.backend.clinicaOdontologica.dto.entrada.odontologo.OdontologoEntradaDto;
import com.backend.clinicaOdontologica.dto.entrada.paciente.DomicilioEntradaDto;
import com.backend.clinicaOdontologica.dto.entrada.paciente.PacienteEntradaDto;
import com.backend.clinicaOdontologica.dto.entrada.turno.TurnoEntradaDto;
import com.backend.clinicaOdontologica.dto.salida.odontologo.OdontologoSalidaDto;
import com.backend.clinicaOdontologica.dto.salida.paciente.PacienteSalidaDto;
import com.backend.clinicaOdontologica.dto.salida.turno.OdontologoTurnoSalidaDto;
import com.backend.clinicaOdontologica.dto.salida.turno.PacienteTurnoSalidaDto;
import com.backend.clinicaOdontologica.dto.salida.turno.TurnoSalidaDto;
import com.backend.clinicaOdontologica.exceptions.BadRequestException;
import com.backend.clinicaOdontologica.exceptions.ResourceNotFoundException;
import com.backend.clinicaOdontologica.repository.TurnoRepository;
import com.backend.clinicaOdontologica.service.impl.OdontologoService;
import com.backend.clinicaOdontologica.service.impl.PacienteService;
import com.backend.clinicaOdontologica.service.impl.TurnoService;
import org.junit.Test;
import org.junit.jupiter.api.Order;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TurnoServiceTest {

    @Autowired
    private TurnoService turnoService;

    @Autowired
    private PacienteService pacienteService;

    @Autowired
    private OdontologoService odontologoService;

    @Test
    @Order(1)
    public void deberiaAgregarUnPacienteDeNombreAlejoYRetornarSuId() {
        PacienteEntradaDto pacienteEntradaDto = new PacienteEntradaDto("Alejo", "Jorja", 44346760, LocalDate.of(2023, 9, 24), new DomicilioEntradaDto("Sosneado", 1892, "Córdoba Capital", "Córdoba"));

        try {
            PacienteSalidaDto pacienteSalidaDto = pacienteService.registrarPaciente(pacienteEntradaDto);

            assertNotNull(pacienteSalidaDto.getId());
            assertEquals("Alejo", pacienteSalidaDto.getNombre());
        } catch (Exception e) {
            // Manejar la excepción según tus necesidades
            e.printStackTrace();
        }
    }

    @Test
    @Order(2)
    public void deberiaAgregarUnOdontologoDeNombreDavidYRetornarSuId() {
        OdontologoEntradaDto odontologoEntradaDto = new OdontologoEntradaDto("12345", "David", "Molina");

        try {
            OdontologoSalidaDto odontologoSalidaDto = odontologoService.registrarOdontologo(odontologoEntradaDto);

            assertNotNull(odontologoSalidaDto.getId());
            assertEquals("David", odontologoSalidaDto.getNombre());
        } catch (Exception e) {
            // Manejar la excepción según tus necesidades
            e.printStackTrace();
        }
    }

    @Test
    @Order(3)
    public void deberiaRegistrarUnTurnoParaAlejoConElOdontologoDavidParaElDiaSiguienteAlActual() throws BadRequestException, ResourceNotFoundException {
        // Agregar un paciente y un odontólogo para usar en la prueba
        PacienteEntradaDto pacienteEntradaDto = new PacienteEntradaDto("Alejo", "Jorja", 44346760, LocalDate.of(2023, 9, 24), new DomicilioEntradaDto("Sosneado", 1892, "Córdoba Capital", "Córdoba"));
        PacienteSalidaDto pacienteSalidaDto = pacienteService.registrarPaciente(pacienteEntradaDto);

        OdontologoEntradaDto odontologoEntradaDto = new OdontologoEntradaDto("12345", "David", "Molina");
        OdontologoSalidaDto odontologoSalidaDto = odontologoService.registrarOdontologo(odontologoEntradaDto);


        // Crear un turno de prueba
        TurnoEntradaDto turnoEntradaDto = new TurnoEntradaDto();
        turnoEntradaDto.setPaciente(pacienteSalidaDto.getId());
        turnoEntradaDto.setOdontologo(odontologoSalidaDto.getId());
        turnoEntradaDto.setFechaYHora(LocalDateTime.now().plusDays(1));

        // Ejecutar el método a probar
        TurnoSalidaDto turnoSalidaDto = turnoService.registrarTurno(turnoEntradaDto);

        // Añadir la siguiente línea para imprimir el ID del paciente
        System.out.println("ID del paciente: " + turnoSalidaDto.getPacienteTurnoSalidaDto().getId());

        // Verificar que el resultado no sea nulo
        assertNotNull(turnoSalidaDto);

        // Verificar el paciente
        PacienteTurnoSalidaDto pacienteTurno = turnoSalidaDto.getPacienteTurnoSalidaDto();
        assertNotNull(pacienteTurno);
        assertNotNull(pacienteTurno.getId());

        // Verificar el odontólogo
        OdontologoTurnoSalidaDto odontologoTurno = turnoSalidaDto.getOdontologoTurnoSalidaDto();
        assertNotNull(odontologoTurno);
        assertNotNull(odontologoTurno.getId());

        // Verificar el turno
        assertNotNull(turnoSalidaDto.getId());
        }

    private void assertIdValido(Long id, String mensaje) {
        assertNotNull(id, mensaje);
        assertTrue(id >= 0, mensaje);
    }
}
